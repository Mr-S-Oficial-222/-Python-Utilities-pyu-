#Python Utilities(PYU) 1.0.0
import sys
import os
import random
import time

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def input_choice(text, y, n):
    while True:
        var = input(text)
        if var == y:
            return y  
        elif var == n:
            return n
        else:
            print(f"[!] Opción inválida. Elige '{y}' o '{n}'.")

def pause(mensaje="Press Enter to continue..."):
    input(f"\n[SYSTEM] {mensaje}")
    
def write(text, speed=0.04, end_line=True):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(speed)
    if end_line:
        print()

def save_file(filename, content):
    with open(filename, "w", encoding="utf-8") as file:
        file.write(content)

def read_file(filename):
    try:
        with open(filename, "r", encoding="utf-8") as file:
            return file.read()
    except FileNotFoundError:
        return False
        
def input_number(text):
    while True:
        try:
            return int(input(text))
        except ValueError:
            print("[!] Invalid option. Please enter a number.")
 
def roll(data):
        if isinstance(data, list):
        	return random.choice(data)
        elif isinstance(data, int):
        	return random.randint(1, data)
        else:
        	return random.random()   
        	
def color(text, color_name="white"):
    colors = {
        "red": "\033[0;31m",
    "green": "\033[0;32m",
    "yellow": "\033[0;33m",
    "blue": "\033[0;34m",
    "purple": "\033[0;35m",
    "cyan": "\033[0;36m",
    "white": "\033[0;37m",

    "light_red": "\033[1;31m",
    "light_green": "\033[1;32m",
    "light_yellow": "\033[1;33m",
    "light_blue": "\033[1;34m",
    "light_purple": "\033[1;35m",
    "light_cyan": "\'033[1;36m",
    "bold_white": "\033[1;37m",

    "bg_red": "\033[41m",
    "bg_green": "\033[42m",
    "bg_yellow": "\033[43m",
    "bg_blue": "\033[44m",
    
    "underline": "\033[4m",
    "reset": "\033[0m"
    }
    chosen_color = colors.get(color_name.lower(), colors["white"])
    reset = colors["reset"]
    
    return f"{chosen_color}{text}{reset}"

def progress_bar(label="Loading", seconds=3):
    print(f"{label}:")
    for i in range(1, 21):
        sys.stdout.write(f"\r[{'█' * i}{' ' * (20 - i)}] {i * 5}%")
        sys.stdout.flush()
        time.sleep(seconds / 20)
    print("\n[DONE]")

def input_range(text, min_val, max_val):
    while True:
        num = input_number(text)
        if min_val <= num <= max_val:
            return num
        print(f"[!] Out of range. Enter a number between {min_val} and {max_val}.")

def countdown(segundos):
    for i in range(segundos, 0, -1):
        print(f"Comenzando en... {i}", end="\r")
        time.sleep(1)
    print("Starting in...       ") 
    
def add_line(nombre_archivo, contenido):
    with open(nombre_archivo, "a", encoding="utf-8") as archivo:
        archivo.write(contenido + "\n")

def clear_print(texto):
	clear()
	print(texto)
	
def clear_line():    
    sys.stdout.write("\033[F\033[K")
    sys.stdout.flush()

def safe_input(mensaje, tipo=str):
    while True:
        try:
            entrada = input(mensaje)
            return tipo(entrada)
        except ValueError:
            print(f"Invalid input. Expected {tipo.__name__}. Try again.")
    
def box_print(texto):
    lineas = texto.split('\n')
    largo_max = max(len(l) for l in lineas)
    print("+" + "-" * (largo_max + 2) + "+")
    for l in lineas:
        print(f"| {l.ljust(largo_max)} |")
    print("+" + "-" * (largo_max + 2) + "+")    
    
def menu(title, options, title_color="yellow"):
    clear()
    print(color(f"=== {title.upper()} ===", title_color))
    for i, opcion in enumerate(options, 1):
        print(f"[{i}] {opcion}")
    print("=" * (len(title) + 8))

def banner(texto, decoracion="="):
    linea = decoracion * (len(texto) + 6)
    print(linea)
    print(f"{decoracion}[ {texto.upper()} ]{decoracion}")
    print(linea)
                                                    