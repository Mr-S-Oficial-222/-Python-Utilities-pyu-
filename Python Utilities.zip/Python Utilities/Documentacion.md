
# Python Utilities (PYU) 1.0.0 🐍🛠️
**PYU** es una librería ligera de utilidades para Python diseñada para facilitar el desarrollo de aplicaciones de consola (CLI), interactuar con el usuario de manera segura, aplicar formato visual con colores y manejar archivos de forma sencilla.
## 🚀 Instalación y Requisitos
Para usar esta librería, asegúrate de tener Python 3.x instalado. Puedes guardar el código de la librería en un archivo llamado pyu.py en el directorio de tu proyecto e importarlo de la siguiente manera:
```python
import pyu
# O importar funciones específicas:
from pyu import clear, color, menu, safe_input

```
## 📚 Referencia de Funciones
Las funciones de **PYU** se agrupan en cuatro categorías principales:
 1. Consola e Interfaz Visual
 2. Entrada de Datos del Usuario
 3. Gestión de Archivos
 4. Efectos y Mecánicas de Juego
### 1. Consola e Interfaz Visual
#### clear()
Limpia la pantalla de la terminal de manera multiplataforma (compatible con Windows, macOS y Linux).
 * **Uso:**
   ```python
   pyu.clear()
   
   ```
#### clear_print(texto)
Limpia la pantalla de la terminal y luego imprime inmediatamente el texto especificado.
 * **Parámetros:**
   * texto *(str)*: El texto a imprimir después de limpiar.
 * **Uso:**
   ```python
   pyu.clear_print("¡La pantalla se ha reiniciado!")
   
   ```
#### clear_line()
Borra la última línea impresa en la consola usando códigos de escape ANSI. Es muy útil para corregir o sobreescribir líneas dinámicamente.
 * **Uso:**
   ```python
   print("Cargando datos...")
   pyu.clear_line()
   print("¡Datos cargados con éxito!") # Reemplaza la línea anterior
   
   ```
#### pause(mensaje="Press Enter to continue...")
Detiene la ejecución del programa y muestra un mensaje del sistema hasta que el usuario presione la tecla *Enter*.
 * **Parámetros:**
   * mensaje *(str, opcional)*: Texto personalizado para la pausa.
 * **Uso:**
   ```python
   pyu.pause("Presiona Enter para continuar al siguiente nivel...")
   
   ```
#### write(text, speed=0.04, end_line=True)
Imprime texto carácter por carácter con un efecto de máquina de escribir ("typewriter").
 * **Parámetros:**
   * text *(str)*: El texto a escribir.
   * speed *(float, opcional)*: Segundos de pausa entre cada carácter (por defecto 0.04).
   * end_line *(bool, opcional)*: Si es True, añade un salto de línea al final.
 * **Uso:**
   ```python
   pyu.write("Había una vez en un reino lejano...", speed=0.08)
   
   ```
#### color(text, color_name="white")
Formatea una cadena de texto agregándole códigos ANSI para cambiar su color en la consola.
 * **Parámetros:**
   * text *(str)*: El texto que deseas colorear.
   * color_name *(str, opcional)*: El nombre del color (por defecto "white").
 * **Colores Disponibles:**
   * Estándar: "red", "green", "yellow", "blue", "purple", "cyan", "white".
   * Brillantes/Negrita: "light_red", "light_green", "light_yellow", "light_blue", "light_purple", "light_cyan", "bold_white".
   * Fondos (Background): "bg_red", "bg_green", "bg_yellow", "bg_blue".
   * Formato extra: "underline".
 * **Uso:**
   ```python
   print(pyu.color("¡Acceso denegado!", "red"))
   print(pyu.color("Éxito total", "light_green"))
   
   ```
#### box_print(texto)
Dibuja un marco o caja de texto alrededor del texto proporcionado, adaptando el ancho automáticamente al contenido. Admite saltos de línea.
 * **Parámetros:**
   * texto *(str)*: El contenido que irá dentro del cuadro.
 * **Uso:**
   ```python
   pyu.box_print("SISTEMA OPERATIVO v2.0\nIniciado correctamente.")
   
   ```
   *Salida:*
   ```text
   +-------------------------+
   | SISTEMA OPERATIVO v2.0  |
   | Iniciado correctamente. |
   +-------------------------+
   
   ```
#### menu(title, options, title_color="yellow")
Limpia la pantalla y muestra un menú interactivo con un título y una lista numerada de opciones con diseño estético.
 * **Parámetros:**
   * title *(str)*: El título del menú.
   * options *(list)*: Una lista de strings que representan las opciones disponibles.
   * title_color *(str, opcional)*: El color del título del menú.
 * **Uso:**
   ```python
   opciones = ["Jugar", "Configuración", "Créditos", "Salir"]
   pyu.menu("Menú Principal", opciones, title_color="cyan")
   
   ```
#### banner(texto, decoracion="=")
Genera un banner decorativo llamativo en la consola con el texto en mayúsculas.
 * **Parámetros:**
   * texto *(str)*: Texto principal del banner.
   * decoracion *(str, opcional)*: El carácter que se usará para construir los bordes del banner.
 * **Uso:**
   ```python
   pyu.banner("Atención: Alerta de Virus", decoracion="*")
   
   ```
### 2. Entrada de Datos del Usuario
#### input_choice(text, y, n)
Solicita al usuario una respuesta entre exactamente dos opciones definidas (por ejemplo, 's' o 'n'). Si la entrada no coincide con ninguna de las opciones, repite la solicitud de forma persistente.
 * **Parámetros:**
   * text *(str)*: El mensaje de prompt que se mostrará.
   * y *(str)*: Opción afirmativa o primera opción.
   * n *(str)*: Opción negativa o segunda opción.
 * **Retorna:** La opción seleccionada (y o n).
 * **Uso:**
   ```python
   decision = pyu.input_choice("¿Deseas guardar los cambios? (s/n): ", "s", "n")
   
   ```
#### input_number(text)
Solicita una entrada numérica entera al usuario. Maneja automáticamente los errores de tipo de dato (ValueError) evitando que el programa se cierre de forma imprevista si el usuario ingresa letras o símbolos.
 * **Parámetros:**
   * text *(str)*: Mensaje para solicitar el número.
 * **Retorna:** El número entero (int) introducido.
 * **Uso:**
   ```python
   edad = pyu.input_number("Introduce tu edad: ")
   
   ```
#### input_range(text, min_val, max_val)
Solicita una entrada numérica entera y valida de forma estricta que se encuentre dentro del rango definido (inclusive).
 * **Parámetros:**
   * text *(str)*: Mensaje para solicitar el número.
   * min_val *(int)*: Límite inferior permitido.
   * max_val *(int)*: Límite superior permitido.
 * **Retorna:** El número entero validado dentro del rango.
 * **Uso:**
   ```python
   opcion = pyu.input_range("Elige una opción (1-4): ", 1, 4)
   
   ```
#### safe_input(mensaje, tipo=str)
Una función genérica y segura para recibir cualquier tipo de dato (str, int, float, etc.). Si la conversión al tipo especificado falla, vuelve a preguntar de forma limpia.
 * **Parámetros:**
   * mensaje *(str)*: Mensaje de solicitud.
   * tipo *(type, opcional)*: La clase o tipo de dato requerido (por defecto str).
 * **Retorna:** La entrada convertida de forma segura al tipo especificado.
 * **Uso:**
   ```python
   # Solicitar un flotante de forma segura
   precio = pyu.safe_input("Ingresa el precio del artículo: ", float)
   
   ```
### 3. Gestión de Archivos
#### save_file(filename, content)
Crea o sobrescribe un archivo de texto con codificación UTF-8 de manera rápida y directa.
 * **Parámetros:**
   * filename *(str)*: El nombre o ruta del archivo.
   * content *(str)*: El contenido de texto que se guardará.
 * **Uso:**
   ```python
   pyu.save_file("config.txt", "idioma=es\nvolumen=80")
   
   ```
#### add_line(nombre_archivo, contenido)
Abre un archivo de texto en modo anexión (*append*) y le añade una nueva línea al final del documento.
 * **Parámetros:**
   * nombre_archivo *(str)*: El nombre o ruta del archivo.
   * contenido *(str)*: El contenido que se añadirá como una nueva línea.
 * **Uso:**
   ```python
   pyu.add_line("historial.log", "Usuario inició sesión a las 10:00")
   
   ```
#### read_file(filename)
Lee y retorna todo el contenido de un archivo de texto de forma segura. Si el archivo no existe, no arroja un error letal, sino que retorna False.
 * **Parámetros:**
   * filename *(str)*: El nombre o ruta del archivo a leer.
 * **Retorna:** El contenido del archivo en string, o False si el archivo no se encuentra.
 * **Uso:**
   ```python
   datos = pyu.read_file("datos.txt")
   if datos:
       print("Contenido cargado:", datos)
   else:
       print("El archivo no existe.")
   
   ```
### 4. Efectos y Mecánicas de Juego
#### roll(data)
Un motor de aleatoriedad multipropósito. Su comportamiento se adapta inteligentemente según el tipo de dato que reciba:
 * **Comportamiento:**
   * Si recibe una **lista**, selecciona un elemento al azar (como lanzar un dado con nombres o items).
   * Si recibe un **entero**, devuelve un número aleatorio entre 1 y ese entero (como lanzar un dado numérico de N caras).
   * Si recibe cualquier otro tipo de dato, devuelve un decimal aleatorio entre 0.0 y 1.0.
 * **Parámetros:**
   * data *(list | int | any)*: El objeto de origen para realizar el "roll".
 * **Uso:**
   ```python
   # Caso 1: Lanzar un dado de 6 caras
   resultado_dado = pyu.roll(6) # Retorna un entero entre 1 y 6
   
   # Caso 2: Seleccionar un botín aleatorio
   items = ["Espada", "Escudo", "Poción", "Llave"]
   recompensa = pyu.roll(items) # Retorna uno de los elementos de la lista
   
   # Caso 3: Probabilidad porcentual (decimal de 0 a 1)
   probabilidad = pyu.roll(None) # Retorna un float (ej. 0.4578...)
   
   ```
#### progress_bar(label="Loading", seconds=3)
Dibuja una barra de progreso animada interactiva con indicador visual de carga (█) y porcentaje de avance.
 * **Parámetros:**
   * label *(str, opcional)*: Texto a mostrar encima de la barra (ej: "Instalando", "Descargando").
   * seconds *(int | float, opcional)*: El tiempo de duración total de la animación en segundos.
 * **Uso:**
   ```python
   pyu.progress_bar("Buscando actualizaciones", seconds=4)
   
   ```
#### countdown(segundos)
Inicia una cuenta regresiva visual que actualiza la misma línea de la consola dinámicamente cada segundo.
 * **Parámetros:**
   * segundos *(int)*: La cantidad de segundos desde donde partirá el conteo.
 * **Uso:**
   ```python
   pyu.countdown(5)
   
   ```
## 🛠️ Ejemplo Práctico Integrado
Aquí tienes un pequeño script interactivo de ejemplo que muestra el poder de **PYU** combinando múltiples funciones en una interfaz de consola pulida:
```python
import pyu

def jugar():
    pyu.clear()
    pyu.banner("Aventura Aleatoria")
    
    pyu.write("Te encuentras frente a dos misteriosos cofres...", speed=0.03)
    pyu.pause()
    
    # Barra de carga con progreso animado
    pyu.progress_bar("Abriendo cofre misterioso", seconds=2)
    
    # Uso de la función roll con una lista
    premios = ["Espada de Fuego", "Moneda de Oro", "Cofre Vacío", "Veneno"]
    recompensa = pyu.roll(premios)
    
    # Mensaje coloreado según el resultado
    if recompensa == "Veneno":
        print(pyu.color(f"\n¡Mala suerte! Encontraste: {recompensa}", "red"))
    else:
        print(pyu.color(f"\n¡Enhorabuena! Has obtenido: {recompensa}", "green"))
    
    pyu.pause()

def main():
    opciones = ["Iniciar Aventura", "Ver Instrucciones", "Salir"]
    
    while True:
        pyu.menu("Menú PYU", opciones, title_color="cyan")
        seleccion = pyu.input_range("Elige una opción: ", 1, len(opciones))
        
        if seleccion == 1:
            jugar()
        elif seleccion == 2:
            pyu.clear()
            pyu.box_print("INSTRUCCIONES\n1. Elige tu camino.\n2. Deja que el azar (roll) decida.\n3. ¡Diviértete!")
            pyu.pause()
        elif seleccion == 3:
            pyu.clear()
            pyu.write("¡Gracias por jugar con PYU!", speed=0.05)
            break

if __name__ == "__main__":
    main()

```
